create function st_asx3d(geom geometry, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0) returns text
    immutable
    parallel safe
    language sql
as
$$
SELECT public._ST_AsX3D(3,$1,$2,$3,'');
$$;

alter function st_asx3d(geometry, integer, integer) owner to postgres;

