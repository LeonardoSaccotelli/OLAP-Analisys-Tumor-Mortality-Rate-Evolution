create function st_buffer(geography, double precision, integer) returns geography
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.geography(public.ST_Transform(public.ST_Buffer(public.ST_Transform(public.geometry($1), public._ST_BestSRID($1)), $2, $3), 4326))
$$;

comment on function st_buffer(geography, double precision, integer) is 'args: g1, radius_of_buffer, num_seg_quarter_circle - (T)Returns a geometry covering all points within a given distancefrom the input geometry.';

alter function st_buffer(geography, double precision, integer) owner to postgres;

